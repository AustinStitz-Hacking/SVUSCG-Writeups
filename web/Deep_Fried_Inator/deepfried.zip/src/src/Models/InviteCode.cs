namespace DeepFriedinator.Models;

public class InviteCode
{
    public int Id { get; set; }
    public string Code { get; set; } = "";
}
